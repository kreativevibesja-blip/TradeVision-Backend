//+------------------------------------------------------------------+
//|                                          GoldX_SMC_EA.mq5        |
//|              GoldX SMC Engine with GoldX Licensing              |
//+------------------------------------------------------------------+
#property copyright "GoldX"
#property version   "1.00"
#property strict

#include <Trade\Trade.mqh>

input string          LicenseKey                 = "";
input string          LicenseServerUrl           = "https://tradevision-backend-ic8y.onrender.com/api/goldx";
input string          HmacSecret                 = "3f15f3d48799e2bde1efc2b2a438a6b4eabb0c003d2ef232a6ce73e6b2ca0f69";
input int             LicenseCacheSeconds        = 600;
input bool            EnableTrading              = true;
input ENUM_TIMEFRAMES AnalysisTimeframe          = PERIOD_M5;
input int             AnalysisBars               = 600;
input int             SwingLookback              = 3;
input double          LotSize                    = 0.0;
input double          RiskPercent                = 1.0;
input int             MaxTrades                  = 3;
input int             Slippage                   = 20;
input double          TP_Points                  = 500.0;
input double          SL_Points                  = 250.0;
input bool            UseRR                      = true;
input double          RiskReward                 = 2.0;
input bool            UseEMASetupFilter          = true;
input int             FastEMAPeriod              = 9;
input int             MidEMAPeriod               = 14;
input int             SlowEMAPeriod              = 50;
input int             EmaPullbackTolerancePoints = 30;
input int             EmaPullbackLookbackBars    = 4;
input int             EmaCrossLookbackBars       = 3;
input bool            MoveStopToBreakEven        = true;
input double          BreakEvenAtRR              = 1.0;
input bool            UseBOS                     = true;
input bool            UseCHOCH                   = true;
input bool            UseFVG                     = true;
input bool            UseSupplyDemand            = true;
input bool            UseLiquidity               = true;
input int             SignalValidityBars         = 3;
input int             TradeCooldownSeconds       = 300;
input int             ClosedTradeCooldownHours   = 5;
input int             SpreadLimitPoints          = 80;
input bool            UseTradingHours            = false;
input int             TradingStartHour           = 7;
input int             TradingEndHour             = 20;
input bool            UseNewsFilterPlaceholder   = false;
input int             ZoneProjectionBars         = 80;
input int             MinZoneSizePoints          = 50;
input double          ZoneImpulseMultiplier      = 1.2;
input int             LiquidityTolerancePoints   = 20;
input int             DuplicateLevelBufferPoints = 30;
input int             MaxStoredZones             = 40;
input int             MaxStoredLiquidity         = 20;
input bool            ShowDrawingsAndLabels      = true;
input ulong           MagicNumber                = 26042026;

CTrade trade;

enum TrendDirection
{
   TREND_NONE = 0,
   TREND_BULL = 1,
   TREND_BEAR = -1
};

struct SwingPoint
{
   int shift;
   datetime time;
   double price;
   bool isHigh;
};

struct PriceZone
{
   double high;
   double low;
   datetime createdAt;
   datetime endAt;
   bool bullish;
   bool active;
   string kind;
   string objectName;
};

struct LiquidityLevel
{
   double price;
   datetime createdAt;
   bool highs;
   bool active;
   string objectName;
};

string PREFIX_ROOT       = "GoldX.SMC.";
string PREFIX_ZONES      = "GoldX.SMC.Zone.";
string PREFIX_LIQUIDITY  = "GoldX.SMC.Liq.";
string PREFIX_STRUCTURE  = "GoldX.SMC.Structure.";

color COLOR_SUPPLY       = C'255,182,182';
color COLOR_DEMAND       = C'182,255,182';
color COLOR_BULL_FVG     = C'170,235,170';
color COLOR_BEAR_FVG     = C'255,205,205';

double EffectiveLiquidityTolerance(MqlRates &rates[])
{
   double avgRangePoints = AverageRangePoints(rates, 1, MathMin(40, ArraySize(rates) - 1));
   return MathMax((double)LiquidityTolerancePoints, avgRangePoints * 0.12) * PointValue();
}

bool            g_licenseValid = false;
datetime        g_lastLicenseCheck = 0;
string          g_lastLicenseError = "";
string          g_sessionToken = "";
datetime        g_sessionExpiry = 0;
datetime        g_lastAnalysisBar = 0;
TrendDirection  g_trendDirection = TREND_NONE;
datetime        g_recentBullStructureTime = 0;
datetime        g_recentBearStructureTime = 0;
datetime        g_recentBullSweepTime = 0;
datetime        g_recentBearSweepTime = 0;
double          g_recentBullStructureLevel = 0.0;
double          g_recentBearStructureLevel = 0.0;
double          g_lastTradeLevel = 0.0;
int             g_lastTradeDirection = 0;
datetime        g_lastTradeTime = 0;
datetime        g_lastClosedTradeTime = 0;
datetime        g_lastBullBreakAnchor = 0;
datetime        g_lastBearBreakAnchor = 0;
datetime        g_lastDecisionLogBar = 0;
ulong           g_lastProcessedCloseDeal = 0;
int             g_fastEmaHandle = INVALID_HANDLE;
int             g_midEmaHandle = INVALID_HANDLE;
int             g_slowEmaHandle = INVALID_HANDLE;

PriceZone       g_zones[];
LiquidityLevel  g_liquidity[];

double PointValue()
{
   return SymbolInfoDouble(_Symbol, SYMBOL_POINT);
}

ENUM_TIMEFRAMES ActiveTimeframe()
{
   if(AnalysisTimeframe == PERIOD_CURRENT)
      return (ENUM_TIMEFRAMES)_Period;
   return AnalysisTimeframe;
}

double NormalizePrice(double value)
{
   return NormalizeDouble(value, (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS));
}

double NormalizeVolume(double volume)
{
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(step <= 0.0)
      step = 0.01;

   volume = MathMax(minLot, MathMin(maxLot, volume));
   volume = MathFloor(volume / step) * step;
   return NormalizeDouble(MathMax(minLot, volume), 2);
}

string HmacSha256(string key, string message)
{
   uchar keyBytes[];
   uchar msgBytes[];
   uchar keyPadded[];
   uchar innerPad[];
   uchar outerPad[];
   uchar innerData[];
   uchar innerHash[];
   uchar outerData[];
   uchar finalHash[];
   uchar dummy[];

   StringToCharArray(key, keyBytes, 0, StringLen(key));
   StringToCharArray(message, msgBytes, 0, StringLen(message));

   ArrayResize(keyPadded, 64);
   ArrayInitialize(keyPadded, 0);

   if(ArraySize(keyBytes) > 64)
   {
      uchar keyHash[];
      CryptEncode(CRYPT_HASH_SHA256, keyBytes, keyPadded, keyHash);
      ArrayCopy(keyPadded, keyHash, 0, 0, MathMin(ArraySize(keyHash), 64));
   }
   else
   {
      ArrayCopy(keyPadded, keyBytes, 0, 0, MathMin(ArraySize(keyBytes), 64));
   }

   ArrayResize(innerPad, 64);
   ArrayResize(outerPad, 64);
   for(int i = 0; i < 64; i++)
   {
      innerPad[i] = (uchar)(keyPadded[i] ^ 0x36);
      outerPad[i] = (uchar)(keyPadded[i] ^ 0x5C);
   }

   ArrayResize(innerData, 64 + ArraySize(msgBytes));
   ArrayCopy(innerData, innerPad, 0, 0, 64);
   ArrayCopy(innerData, msgBytes, 64, 0, ArraySize(msgBytes));
   CryptEncode(CRYPT_HASH_SHA256, innerData, dummy, innerHash);

   ArrayResize(outerData, 64 + ArraySize(innerHash));
   ArrayCopy(outerData, outerPad, 0, 0, 64);
   ArrayCopy(outerData, innerHash, 64, 0, ArraySize(innerHash));
   CryptEncode(CRYPT_HASH_SHA256, outerData, dummy, finalHash);

   string result = "";
   for(int j = 0; j < ArraySize(finalHash); j++)
      result += StringFormat("%02x", finalHash[j]);
   return result;
}

string GetDeviceId()
{
   return StringFormat(
      "%s-%d-%s",
      AccountInfoString(ACCOUNT_SERVER),
      (int)AccountInfoInteger(ACCOUNT_LOGIN),
      TerminalInfoString(TERMINAL_NAME)
   );
}

string GenerateNonce()
{
   string seed = StringFormat(
      "%s|%s|%I64d|%d|%d|%d|%d",
      Symbol(),
      GetDeviceId(),
      ChartID(),
      (int)AccountInfoInteger(ACCOUNT_LOGIN),
      (int)TimeCurrent(),
      GetTickCount(),
      MathRand()
   );

   uchar seedBytes[];
   uchar hashBytes[];
   uchar dummy[];
   StringToCharArray(seed, seedBytes, 0, StringLen(seed));
   CryptEncode(CRYPT_HASH_SHA256, seedBytes, dummy, hashBytes);

   string nonce = "";
   int limit = MathMin(ArraySize(hashBytes), 16);
   for(int i = 0; i < limit; i++)
      nonce += StringFormat("%02x", hashBytes[i]);

   if(nonce == "")
      nonce = StringFormat("%d%I64d%d", (int)TimeCurrent(), ChartID(), GetTickCount());

   return nonce;
}

string JsonGetString(string json, string key)
{
   string search = "\"" + key + "\"";
   int pos = StringFind(json, search);
   if(pos < 0) return "";

   pos = StringFind(json, ":", pos);
   if(pos < 0) return "";

   pos++;
   while(pos < StringLen(json) && (StringGetCharacter(json, pos) == ' ' || StringGetCharacter(json, pos) == '"'))
      pos++;

   int endPos = pos;
   bool inQuote = pos > 0 && StringGetCharacter(json, pos - 1) == '"';
   if(inQuote)
   {
      endPos = StringFind(json, "\"", pos);
      if(endPos < 0) return "";
   }
   else
   {
      while(endPos < StringLen(json))
      {
         ushort ch = StringGetCharacter(json, endPos);
         if(ch == ',' || ch == '}' || ch == ' ' || ch == '\n' || ch == '\r')
            break;
         endPos++;
      }
   }
   return StringSubstr(json, pos, endPos - pos);
}

bool JsonGetBool(string json, string key)
{
   string value = JsonGetString(json, key);
   StringToLower(value);
   return value == "true" || value == "1";
}

bool DeleteObjectsByPrefix(string prefix)
{
   bool removed = false;
   for(int i = ObjectsTotal(0) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i);
      if(StringFind(name, prefix) == 0)
      {
         ObjectDelete(0, name);
         removed = true;
      }
   }
   return removed;
}

void RefreshLastClosedTradeTime(int lookbackDays=30)
{
   g_lastClosedTradeTime = 0;
   g_lastProcessedCloseDeal = 0;

   datetime endTime = TimeCurrent();
   if(endTime <= 0)
      endTime = TimeTradeServer();
   if(endTime <= 0)
      endTime = TimeLocal();

   datetime startTime = endTime - (lookbackDays * 86400);
   if(!HistorySelect(startTime, endTime))
      return;

   int totalDeals = HistoryDealsTotal();
   for(int i = totalDeals - 1; i >= 0; i--)
   {
      ulong dealTicket = HistoryDealGetTicket(i);
      if(dealTicket == 0)
         continue;
      if(HistoryDealGetString(dealTicket, DEAL_SYMBOL) != _Symbol)
         continue;
      if((ulong)HistoryDealGetInteger(dealTicket, DEAL_MAGIC) != MagicNumber)
         continue;

      long entryType = HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
      if(entryType != DEAL_ENTRY_OUT && entryType != DEAL_ENTRY_OUT_BY)
         continue;

      g_lastClosedTradeTime = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);
      g_lastProcessedCloseDeal = dealTicket;
      break;
   }
}

bool IsClosedTradeCooldownActive()
{
   if(ClosedTradeCooldownHours <= 0 || g_lastClosedTradeTime <= 0)
      return false;

   return (TimeCurrent() - g_lastClosedTradeTime) < (ClosedTradeCooldownHours * 3600);
}

datetime ResolveLicenseTimestamp()
{
   datetime gmtNow = TimeGMT();
   datetime tradeServerNow = TimeTradeServer();
   datetime currentQuoteTime = TimeCurrent();

   if(tradeServerNow > 0 && MathAbs((int)(tradeServerNow - gmtNow)) <= 300)
      return tradeServerNow;

   if(currentQuoteTime > 0 && MathAbs((int)(currentQuoteTime - gmtNow)) <= 300)
      return currentQuoteTime;

   if(gmtNow > 0)
      return gmtNow;

   return TimeLocal();
}

bool VerifyLicense(bool force=false)
{
   if(!force && g_licenseValid && (TimeCurrent() - g_lastLicenseCheck) < LicenseCacheSeconds)
      return true;

   if(LicenseKey == "")
   {
      g_lastLicenseError = "License key required";
      g_licenseValid = false;
      return false;
   }

   string mt5Account = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
   string deviceId = GetDeviceId();
   long timestamp = (long)ResolveLicenseTimestamp();
   string nonce = GenerateNonce();
   string payload = LicenseKey + ":" + mt5Account + ":" + deviceId + ":" + IntegerToString(timestamp) + ":" + nonce;
   string signature = HmacSha256(HmacSecret, payload);
   string body = StringFormat(
      "{\"licenseKey\":\"%s\",\"mt5Account\":\"%s\",\"deviceId\":\"%s\",\"timestamp\":%d,\"nonce\":\"%s\"}",
      LicenseKey,
      mt5Account,
      deviceId,
      timestamp,
      nonce
   );

   char requestData[];
   char result[];
   StringToCharArray(body, requestData, 0, StringLen(body));
   string headers = "Content-Type: application/json\r\nX-GoldX-Signature: " + signature + "\r\n";
   string resultHeaders;
   int status = WebRequest("POST", LicenseServerUrl + "/license/verify", headers, 10000, requestData, result, resultHeaders);

   g_lastLicenseCheck = TimeCurrent();

   if(status == -1)
   {
      g_lastLicenseError = StringFormat("WebRequest failed (%d)", GetLastError());
      g_licenseValid = false;
      return false;
   }

   string response = CharArrayToString(result, 0, ArraySize(result));
   g_licenseValid = JsonGetBool(response, "valid");
   g_lastLicenseError = g_licenseValid ? "" : JsonGetString(response, "error");
   if(!g_licenseValid && g_lastLicenseError == "")
      g_lastLicenseError = response == "" ? StringFormat("HTTP %d", status) : response;

   if(g_licenseValid)
   {
      g_sessionToken = JsonGetString(response, "sessionToken");
      g_sessionExpiry = TimeCurrent() + MathMax(LicenseCacheSeconds, 540);
   }

   return g_licenseValid;
}

bool IsTradingHourAllowed()
{
   if(!UseTradingHours)
      return true;

   MqlDateTime tm;
   TimeToStruct(TimeCurrent(), tm);
   if(TradingStartHour <= TradingEndHour)
      return tm.hour >= TradingStartHour && tm.hour <= TradingEndHour;
   return tm.hour >= TradingStartHour || tm.hour <= TradingEndHour;
}

bool PassesNewsFilterPlaceholder()
{
   if(!UseNewsFilterPlaceholder)
      return true;

   return true;
}

bool PassesSpreadFilter()
{
   double spreadPoints = (SymbolInfoDouble(_Symbol, SYMBOL_ASK) - SymbolInfoDouble(_Symbol, SYMBOL_BID)) / PointValue();
   return spreadPoints <= SpreadLimitPoints;
}

bool IsNewAnalysisBar()
{
   datetime currentBar = iTime(_Symbol, ActiveTimeframe(), 0);
   if(currentBar == 0)
      return false;
   if(currentBar == g_lastAnalysisBar)
      return false;
   g_lastAnalysisBar = currentBar;
   return true;
}

bool LoadRates(MqlRates &rates[])
{
   int barsToCopy = MathMax(AnalysisBars, SwingLookback * 6 + 60);
   int copied = CopyRates(_Symbol, ActiveTimeframe(), 0, barsToCopy, rates);
   if(copied <= 0)
      return false;
   ArraySetAsSeries(rates, true);
   return copied > SwingLookback * 3 + 10;
}

bool InitializeEmaHandles()
{
   if(!UseEMASetupFilter)
      return true;

   ENUM_TIMEFRAMES timeframe = ActiveTimeframe();
   g_fastEmaHandle = iMA(_Symbol, timeframe, FastEMAPeriod, 0, MODE_EMA, PRICE_CLOSE);
   g_midEmaHandle = iMA(_Symbol, timeframe, MidEMAPeriod, 0, MODE_EMA, PRICE_CLOSE);
   g_slowEmaHandle = iMA(_Symbol, timeframe, SlowEMAPeriod, 0, MODE_EMA, PRICE_CLOSE);

   return g_fastEmaHandle != INVALID_HANDLE && g_midEmaHandle != INVALID_HANDLE && g_slowEmaHandle != INVALID_HANDLE;
}

void ReleaseEmaHandles()
{
   if(g_fastEmaHandle != INVALID_HANDLE)
      IndicatorRelease(g_fastEmaHandle);
   if(g_midEmaHandle != INVALID_HANDLE)
      IndicatorRelease(g_midEmaHandle);
   if(g_slowEmaHandle != INVALID_HANDLE)
      IndicatorRelease(g_slowEmaHandle);

   g_fastEmaHandle = INVALID_HANDLE;
   g_midEmaHandle = INVALID_HANDLE;
   g_slowEmaHandle = INVALID_HANDLE;
}

bool ReadLatestEmaValues(double &fastEma, double &midEma, double &slowEma)
{
   if(!UseEMASetupFilter)
      return true;
   if(g_fastEmaHandle == INVALID_HANDLE || g_midEmaHandle == INVALID_HANDLE || g_slowEmaHandle == INVALID_HANDLE)
      return false;

   double fastBuffer[];
   double midBuffer[];
   double slowBuffer[];
   ArraySetAsSeries(fastBuffer, true);
   ArraySetAsSeries(midBuffer, true);
   ArraySetAsSeries(slowBuffer, true);

   if(CopyBuffer(g_fastEmaHandle, 0, 1, 1, fastBuffer) < 1)
      return false;
   if(CopyBuffer(g_midEmaHandle, 0, 1, 1, midBuffer) < 1)
      return false;
   if(CopyBuffer(g_slowEmaHandle, 0, 1, 1, slowBuffer) < 1)
      return false;

   fastEma = fastBuffer[0];
   midEma = midBuffer[0];
   slowEma = slowBuffer[0];
   return true;
}

bool PassesEmaSetupFilter(bool isBuy)
{
   if(!UseEMASetupFilter)
      return true;

   MqlRates bars[];
   int lookbackBars = MathMax(6, MathMax(EmaPullbackLookbackBars + 2, EmaCrossLookbackBars + 2));
   if(CopyRates(_Symbol, ActiveTimeframe(), 1, lookbackBars, bars) < lookbackBars)
      return false;
   ArraySetAsSeries(bars, true);

   if(g_fastEmaHandle == INVALID_HANDLE || g_midEmaHandle == INVALID_HANDLE || g_slowEmaHandle == INVALID_HANDLE)
      return false;

   double fastBuffer[];
   double midBuffer[];
   double slowBuffer[];
   ArraySetAsSeries(fastBuffer, true);
   ArraySetAsSeries(midBuffer, true);
   ArraySetAsSeries(slowBuffer, true);

   if(CopyBuffer(g_fastEmaHandle, 0, 1, lookbackBars, fastBuffer) < lookbackBars)
      return false;
   if(CopyBuffer(g_midEmaHandle, 0, 1, lookbackBars, midBuffer) < lookbackBars)
      return false;
   if(CopyBuffer(g_slowEmaHandle, 0, 1, lookbackBars, slowBuffer) < lookbackBars)
      return false;

   double tolerance = MathMax(0, EmaPullbackTolerancePoints) * PointValue();
   MqlRates latestClosedBar = bars[0];
   bool recentCross = false;
   int crossWindow = MathMin(lookbackBars - 1, MathMax(1, EmaCrossLookbackBars));

   for(int i = 0; i < crossWindow; i++)
   {
      double fastEma = fastBuffer[i];
      double midEma = midBuffer[i];
      double slowEma = slowBuffer[i];
      MqlRates crossBar = bars[i];

      if(isBuy)
      {
         bool crossedFromBelow = crossBar.open <= (slowEma + tolerance) || crossBar.low <= (slowEma + tolerance);
         bool closedAboveStack = crossBar.close > (fastEma + tolerance)
                              && crossBar.close > (midEma + tolerance)
                              && crossBar.close > (slowEma + tolerance);
         if(crossedFromBelow && closedAboveStack)
         {
            recentCross = true;
            break;
         }
      }
      else
      {
         bool crossedFromAbove = crossBar.open >= (slowEma - tolerance) || crossBar.high >= (slowEma - tolerance);
         bool closedBelowStack = crossBar.close < (fastEma - tolerance)
                              && crossBar.close < (midEma - tolerance)
                              && crossBar.close < (slowEma - tolerance);
         if(crossedFromAbove && closedBelowStack)
         {
            recentCross = true;
            break;
         }
      }
   }

   double latestFastEma = fastBuffer[0];
   double latestMidEma = midBuffer[0];
   double latestSlowEma = slowBuffer[0];

   if(isBuy)
   {
      bool stacked = latestFastEma > latestMidEma && latestMidEma > latestSlowEma;
      bool latestAboveStack = latestClosedBar.close > (latestFastEma + tolerance)
                           && latestClosedBar.close > (latestMidEma + tolerance)
                           && latestClosedBar.close > (latestSlowEma + tolerance);
      return stacked && latestAboveStack && recentCross;
   }

   bool stacked = latestFastEma < latestMidEma && latestMidEma < latestSlowEma;
   bool latestBelowStack = latestClosedBar.close < (latestFastEma - tolerance)
                        && latestClosedBar.close < (latestMidEma - tolerance)
                        && latestClosedBar.close < (latestSlowEma - tolerance);
   return stacked && latestBelowStack && recentCross;
}

void ManageOpenPositions()
{
   if(!MoveStopToBreakEven || BreakEvenAtRR <= 0.0)
      return;

   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double point = PointValue();
   double minimumDistance = ResolveMinimumStopDistancePrice();
   double brokerBuffer = MathMax(point * 2.0, minimumDistance * 0.05);
   double requiredDistance = minimumDistance + brokerBuffer;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol)
         continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;

      ENUM_POSITION_TYPE positionType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double entry = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      if(sl <= 0.0)
         continue;

      if(positionType == POSITION_TYPE_BUY)
      {
         if(sl >= entry)
            continue;
         double initialRisk = entry - sl;
         if(initialRisk <= 0.0)
            continue;
         double trigger = entry + (initialRisk * BreakEvenAtRR);
         if(bid < trigger)
            continue;

         if((bid - entry) <= requiredDistance)
            continue;

         double newSl = NormalizePrice(MathMin(entry, bid - requiredDistance));
         if(newSl <= sl || newSl >= bid)
            continue;

         if(trade.PositionModify(_Symbol, newSl, tp))
            PrintFormat("[GoldX][SMC] BUY moved to BE at %.5f (trigger %.5f)", newSl, trigger);
         else
            PrintFormat("[GoldX][SMC] BUY breakeven move failed retcode=%d bid=%.5f entry=%.5f newSL=%.5f minStop=%.5f", trade.ResultRetcode(), bid, entry, newSl, minimumDistance);
      }
      else if(positionType == POSITION_TYPE_SELL)
      {
         if(sl <= entry)
            continue;
         double initialRisk = sl - entry;
         if(initialRisk <= 0.0)
            continue;
         double trigger = entry - (initialRisk * BreakEvenAtRR);
         if(ask > trigger)
            continue;

         if((entry - ask) <= requiredDistance)
            continue;

         double newSl = NormalizePrice(MathMax(entry, ask + requiredDistance));
         if(newSl >= sl || newSl <= ask)
            continue;

         if(trade.PositionModify(_Symbol, newSl, tp))
            PrintFormat("[GoldX][SMC] SELL moved to BE at %.5f (trigger %.5f)", newSl, trigger);
         else
            PrintFormat("[GoldX][SMC] SELL breakeven move failed retcode=%d ask=%.5f entry=%.5f newSL=%.5f minStop=%.5f", trade.ResultRetcode(), ask, entry, newSl, minimumDistance);
      }
   }
}

double AverageRangePoints(MqlRates &rates[], int startShift, int count)
{
   double total = 0.0;
   int used = 0;
   for(int i = startShift; i < startShift + count && i < ArraySize(rates); i++)
   {
      total += (rates[i].high - rates[i].low) / PointValue();
      used++;
   }
   if(used == 0)
      return 0.0;
   return total / used;
}

bool IsSwingHigh(MqlRates &rates[], int shift)
{
   if(shift < SwingLookback || shift + SwingLookback >= ArraySize(rates))
      return false;

   for(int i = 1; i <= SwingLookback; i++)
   {
      if(rates[shift].high <= rates[shift - i].high || rates[shift].high < rates[shift + i].high)
         return false;
   }
   return true;
}

bool IsSwingLow(MqlRates &rates[], int shift)
{
   if(shift < SwingLookback || shift + SwingLookback >= ArraySize(rates))
      return false;

   for(int i = 1; i <= SwingLookback; i++)
   {
      if(rates[shift].low >= rates[shift - i].low || rates[shift].low > rates[shift + i].low)
         return false;
   }
   return true;
}

int CollectSwings(MqlRates &rates[], bool highs, SwingPoint &swings[], int maxCount)
{
   ArrayResize(swings, 0);
   int found = 0;

   for(int shift = SwingLookback; shift < ArraySize(rates) - SwingLookback && found < maxCount; shift++)
   {
      bool isSwing = highs ? IsSwingHigh(rates, shift) : IsSwingLow(rates, shift);
      if(!isSwing)
         continue;

      ArrayResize(swings, found + 1);
      swings[found].shift = shift;
      swings[found].time = rates[shift].time;
      swings[found].price = highs ? rates[shift].high : rates[shift].low;
      swings[found].isHigh = highs;
      found++;
   }

   return found;
}

void DrawTrendLine(string name, datetime t1, double p1, datetime t2, double p2, color lineColor, ENUM_LINE_STYLE style)
{
   if(!ShowDrawingsAndLabels)
      return;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TREND, 0, t1, p1, t2, p2);
   else
   {
      ObjectMove(0, name, 0, t1, p1);
      ObjectMove(0, name, 1, t2, p2);
   }

   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, style);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 2);
   ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, false);
}

void DrawTextLabel(string name, datetime t1, double price, string text, color textColor)
{
   if(!ShowDrawingsAndLabels)
      return;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_TEXT, 0, t1, price);
   else
      ObjectMove(0, name, 0, t1, price);

   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetInteger(0, name, OBJPROP_COLOR, textColor);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 9);
}

datetime ResolveProjectionEnd(datetime startTime, int barsForward)
{
   return startTime + PeriodSeconds(ActiveTimeframe()) * barsForward;
}

int CountZonesByType(bool bullish, string kind)
{
   int count = 0;
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      if(!g_zones[i].active) continue;
      if(g_zones[i].bullish != bullish) continue;
      if(g_zones[i].kind != kind) continue;
      count++;
   }
   return count;
}

void TrimOldZones(bool bullish, string kind, int keepCount)
{
   while(CountZonesByType(bullish, kind) > keepCount)
   {
      int oldestIndex = -1;
      datetime oldestTime = LONG_MAX;
      for(int i = 0; i < ArraySize(g_zones); i++)
      {
         if(!g_zones[i].active) continue;
         if(g_zones[i].bullish != bullish) continue;
         if(g_zones[i].kind != kind) continue;
         if(g_zones[i].createdAt < oldestTime)
         {
            oldestTime = g_zones[i].createdAt;
            oldestIndex = i;
         }
      }

      if(oldestIndex < 0)
         return;

      ObjectDelete(0, g_zones[oldestIndex].objectName);
      g_zones[oldestIndex].active = false;
   }
}

int CountStructureObjects(string typePrefix)
{
   int count = 0;
   for(int i = ObjectsTotal(0) - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i);
      if(StringFind(name, typePrefix) == 0 && StringFind(name, ".Label.") < 0)
         count++;
   }
   return count;
}

void TrimOldStructureObjects(string typePrefix, int keepCount)
{
   while(CountStructureObjects(typePrefix) > keepCount)
   {
      string oldestBase = "";
      datetime oldestTime = LONG_MAX;
      for(int i = ObjectsTotal(0) - 1; i >= 0; i--)
      {
         string name = ObjectName(0, i);
         if(StringFind(name, typePrefix) != 0 || StringFind(name, ".Label.") >= 0)
            continue;
         string timestampText = StringSubstr(name, StringLen(typePrefix));
         datetime markerTime = (datetime)StringToInteger(timestampText);
         if(markerTime < oldestTime)
         {
            oldestTime = markerTime;
            oldestBase = name;
         }
      }

      if(oldestBase == "")
         return;

      ObjectDelete(0, oldestBase);
      int lastDot = StringFind(oldestBase, ".", 0);
      int searchFrom = 0;
      while(lastDot >= 0)
      {
         int nextDot = StringFind(oldestBase, ".", lastDot + 1);
         if(nextDot < 0)
            break;
         lastDot = nextDot;
      }

      string oldestLabel = oldestBase;
      if(lastDot >= 0)
         oldestLabel = StringSubstr(oldestBase, 0, lastDot) + ".Label" + StringSubstr(oldestBase, lastDot);
      ObjectDelete(0, oldestLabel);
   }
}

color ResolveZoneColor(bool bullish, string kind)
{
   if(kind == "FVG")
      return bullish ? COLOR_BULL_FVG : COLOR_BEAR_FVG;
   return bullish ? COLOR_DEMAND : COLOR_SUPPLY;
}

void DrawZoneRectangle(string name, datetime startTime, datetime endTime, double high, double low, color zoneColor)
{
   if(!ShowDrawingsAndLabels)
      return;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_RECTANGLE, 0, startTime, high, endTime, low);
   else
   {
      ObjectMove(0, name, 0, startTime, high);
      ObjectMove(0, name, 1, endTime, low);
   }

   ObjectSetInteger(0, name, OBJPROP_COLOR, zoneColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_FILL, true);
}

void DrawLiquidityLine(string name, double price, color lineColor)
{
   if(!ShowDrawingsAndLabels)
      return;

   if(ObjectFind(0, name) < 0)
      ObjectCreate(0, name, OBJ_HLINE, 0, 0, price);
   else
      ObjectSetDouble(0, name, OBJPROP_PRICE, price);

   ObjectSetInteger(0, name, OBJPROP_COLOR, lineColor);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DOT);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
}

bool ZoneStillValid(MqlRates &rates[], int originShift, bool bullish, double high, double low)
{
   double invalidationBuffer = LiquidityTolerancePoints * PointValue();
   for(int shift = originShift - 1; shift >= 1; shift--)
   {
      if(bullish && rates[shift].close < (low - invalidationBuffer))
         return false;
      if(!bullish && rates[shift].close > (high + invalidationBuffer))
         return false;
   }
   return true;
}

bool ZoneExists(bool bullish, string kind, double high, double low)
{
   double tolerance = LiquidityTolerancePoints * PointValue();
   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      if(!g_zones[i].active) continue;
      if(g_zones[i].bullish != bullish) continue;
      if(g_zones[i].kind != kind) continue;
      if(MathAbs(g_zones[i].high - high) <= tolerance && MathAbs(g_zones[i].low - low) <= tolerance)
         return true;
   }
   return false;
}

void AddZone(bool bullish, string kind, double high, double low, datetime zoneTime, datetime zoneEndTime=0)
{
   double normalizedHigh = NormalizePrice(MathMax(high, low));
   double normalizedLow = NormalizePrice(MathMin(high, low));
   high = normalizedHigh;
   low = normalizedLow;
   if((high - low) / PointValue() < MinZoneSizePoints)
      return;
   if(ZoneExists(bullish, kind, high, low))
      return;

   int size = ArraySize(g_zones);
   if(size >= MaxStoredZones)
      return;

   ArrayResize(g_zones, size + 1);
   g_zones[size].high = high;
   g_zones[size].low = low;
   g_zones[size].createdAt = zoneTime;
   g_zones[size].endAt = zoneEndTime > zoneTime ? zoneEndTime : ResolveProjectionEnd(zoneTime, kind == "FVG" ? 3 : ZoneProjectionBars);
   g_zones[size].bullish = bullish;
   g_zones[size].active = true;
   g_zones[size].kind = kind;
   g_zones[size].objectName = StringFormat("%s%s.%s.%I64d", PREFIX_ZONES, bullish ? "Bull" : "Bear", kind, zoneTime);

   color zoneColor = ResolveZoneColor(bullish, kind);
   DrawZoneRectangle(g_zones[size].objectName, zoneTime, g_zones[size].endAt, high, low, zoneColor);
   TrimOldZones(bullish, kind, kind == "FVG" ? 2 : 3);
}

bool LiquidityExists(bool highs, double price)
{
   double tolerance = LiquidityTolerancePoints * PointValue();
   for(int i = 0; i < ArraySize(g_liquidity); i++)
   {
      if(!g_liquidity[i].active) continue;
      if(g_liquidity[i].highs != highs) continue;
      if(MathAbs(g_liquidity[i].price - price) <= tolerance)
         return true;
   }
   return false;
}

void AddLiquidity(bool highs, double price, datetime levelTime)
{
   price = NormalizePrice(price);
   if(LiquidityExists(highs, price))
      return;

   int size = ArraySize(g_liquidity);
   if(size >= MaxStoredLiquidity)
      return;

   ArrayResize(g_liquidity, size + 1);
   g_liquidity[size].price = price;
   g_liquidity[size].createdAt = levelTime;
   g_liquidity[size].highs = highs;
   g_liquidity[size].active = true;
   g_liquidity[size].objectName = StringFormat("%s%s.%I64d", PREFIX_LIQUIDITY, highs ? "High" : "Low", levelTime);
   DrawLiquidityLine(g_liquidity[size].objectName, price, highs ? clrRed : clrGreen);
}

void DetectSupplyDemand(MqlRates &rates[])
{
   if(!UseSupplyDemand)
      return;

   int limit = MathMin(ArraySize(rates) - 2, AnalysisBars - 2);
   for(int shift = 2; shift < limit; shift++)
   {
      double avgRange = AverageRangePoints(rates, shift, 8);
      double bodyPoints = MathAbs(rates[shift].close - rates[shift].open) / PointValue();
      double impulseThreshold = MathMax(avgRange * 0.8, (double)MinZoneSizePoints * 0.7);
      if(avgRange <= 0.0 || bodyPoints < avgRange * 0.5)
         continue;

      double futureLowest = rates[shift - 1].low;
      double futureHighest = rates[shift - 1].high;
      for(int lookAhead = 1; lookAhead <= 3 && (shift - lookAhead) >= 1; lookAhead++)
      {
         futureLowest = MathMin(futureLowest, rates[shift - lookAhead].low);
         futureHighest = MathMax(futureHighest, rates[shift - lookAhead].high);
      }

      bool localHigh = rates[shift].high >= rates[shift + 1].high && rates[shift].high >= rates[shift + 2].high;
      bool localLow = rates[shift].low <= rates[shift + 1].low && rates[shift].low <= rates[shift + 2].low;
      bool supply = rates[shift].close > rates[shift].open && localHigh && ((rates[shift].high - futureLowest) / PointValue()) >= impulseThreshold;
      bool demand = rates[shift].close < rates[shift].open && localLow && ((futureHighest - rates[shift].low) / PointValue()) >= impulseThreshold;

      double supplyHigh = rates[shift].high;
      double supplyLow = MathMin(rates[shift].open, rates[shift].close);
      if((supplyHigh - supplyLow) / PointValue() < MinZoneSizePoints)
         supplyLow = rates[shift].low;

      double demandHigh = MathMax(rates[shift].open, rates[shift].close);
      double demandLow = rates[shift].low;
      if((demandHigh - demandLow) / PointValue() < MinZoneSizePoints)
         demandHigh = rates[shift].high;

      if(supply && ZoneStillValid(rates, shift, false, supplyHigh, supplyLow))
         AddZone(false, "SD", supplyHigh, supplyLow, rates[shift].time, ResolveProjectionEnd(rates[shift].time, MathMax(12, ZoneProjectionBars / 3)));

      if(demand && ZoneStillValid(rates, shift, true, demandHigh, demandLow))
         AddZone(true, "SD", demandHigh, demandLow, rates[shift].time, ResolveProjectionEnd(rates[shift].time, MathMax(12, ZoneProjectionBars / 3)));
   }
}

void DetectFVG(MqlRates &rates[])
{
   if(!UseFVG)
      return;

   int limit = MathMin(ArraySize(rates) - 3, AnalysisBars - 3);
   for(int shift = 1; shift < limit; shift++)
   {
      double olderHigh = rates[shift + 2].high;
      double olderLow = rates[shift + 2].low;
      double newerHigh = rates[shift].high;
      double newerLow = rates[shift].low;

      if(olderHigh < newerLow && ZoneStillValid(rates, shift + 2, true, newerLow, olderHigh))
         AddZone(true, "FVG", newerLow, olderHigh, rates[shift + 2].time, rates[shift].time);

      if(olderLow > newerHigh && ZoneStillValid(rates, shift + 2, false, olderLow, newerHigh))
         AddZone(false, "FVG", olderLow, newerHigh, rates[shift + 2].time, rates[shift].time);
   }
}

void DetectLiquidity(MqlRates &rates[])
{
   if(!UseLiquidity)
      return;

   SwingPoint highSwings[];
   SwingPoint lowSwings[];
   int highCount = CollectSwings(rates, true, highSwings, 20);
   int lowCount = CollectSwings(rates, false, lowSwings, 20);
   double tolerance = EffectiveLiquidityTolerance(rates);

   for(int i = 0; i < highCount; i++)
   {
      for(int j = i + 1; j < highCount; j++)
      {
         if(MathAbs(highSwings[i].price - highSwings[j].price) <= tolerance)
            AddLiquidity(true, (highSwings[i].price + highSwings[j].price) * 0.5, highSwings[i].time);
      }
   }

   for(int i = 0; i < lowCount; i++)
   {
      for(int j = i + 1; j < lowCount; j++)
      {
         if(MathAbs(lowSwings[i].price - lowSwings[j].price) <= tolerance)
            AddLiquidity(false, (lowSwings[i].price + lowSwings[j].price) * 0.5, lowSwings[i].time);
      }
   }
}

TrendDirection InferTrend(MqlRates &rates[])
{
   SwingPoint highs[];
   SwingPoint lows[];
   if(CollectSwings(rates, true, highs, 2) < 2 || CollectSwings(rates, false, lows, 2) < 2)
      return g_trendDirection;

   bool higherHigh = highs[0].price > highs[1].price;
   bool higherLow = lows[0].price > lows[1].price;
   bool lowerHigh = highs[0].price < highs[1].price;
   bool lowerLow = lows[0].price < lows[1].price;

   if(higherHigh && higherLow)
      return TREND_BULL;
   if(lowerHigh && lowerLow)
      return TREND_BEAR;
   return g_trendDirection;
}

void RecordBullishStructure(bool choch, double level, datetime swingTime, datetime barTime)
{
   string kind = choch ? "CHoCH" : "BOS";
   string lineName = StringFormat("%s%s.Bull.%I64d", PREFIX_STRUCTURE, kind, barTime);
   string textName = StringFormat("%s%s.Bull.Label.%I64d", PREFIX_STRUCTURE, kind, barTime);
   DrawTrendLine(lineName, swingTime, level, barTime, level, clrGreen, STYLE_SOLID);
   DrawTextLabel(textName, swingTime + ((barTime - swingTime) / 2), level, kind, clrGreen);
   g_recentBullStructureTime = TimeCurrent();
   g_recentBullStructureLevel = level;
   g_lastBullBreakAnchor = swingTime;
   g_trendDirection = TREND_BULL;
   TrimOldStructureObjects(StringFormat("%s%s.Bull.", PREFIX_STRUCTURE, kind), 3);
}

void RecordBearishStructure(bool choch, double level, datetime swingTime, datetime barTime)
{
   string kind = choch ? "CHoCH" : "BOS";
   string lineName = StringFormat("%s%s.Bear.%I64d", PREFIX_STRUCTURE, kind, barTime);
   string textName = StringFormat("%s%s.Bear.Label.%I64d", PREFIX_STRUCTURE, kind, barTime);
   DrawTrendLine(lineName, swingTime, level, barTime, level, clrRed, STYLE_SOLID);
   DrawTextLabel(textName, swingTime + ((barTime - swingTime) / 2), level, kind, clrRed);
   g_recentBearStructureTime = TimeCurrent();
   g_recentBearStructureLevel = level;
   g_lastBearBreakAnchor = swingTime;
   g_trendDirection = TREND_BEAR;
   TrimOldStructureObjects(StringFormat("%s%s.Bear.", PREFIX_STRUCTURE, kind), 3);
}

int FindPreviousSwingShift(MqlRates &rates[], bool highs, int fromShift)
{
   for(int shift = fromShift; shift < ArraySize(rates) - SwingLookback; shift++)
   {
      if(highs && IsSwingHigh(rates, shift))
         return shift;
      if(!highs && IsSwingLow(rates, shift))
         return shift;
   }
   return -1;
}

void EvaluateStructure(MqlRates &rates[])
{
   TrendDirection scanTrend = TREND_NONE;
   datetime latestBullBreakTime = 0;
   datetime latestBearBreakTime = 0;
   double breakBuffer = EffectiveLiquidityTolerance(rates);
   int limit = MathMin(ArraySize(rates) - SwingLookback - 1, AnalysisBars - 1);

   for(int shift = limit; shift >= 1; shift--)
   {
      int prevHighShift = FindPreviousSwingShift(rates, true, shift + 1);
      int prevLowShift = FindPreviousSwingShift(rates, false, shift + 1);
      if(prevHighShift < 0 && prevLowShift < 0)
         continue;

      MqlRates closedBar = rates[shift];
      double candleRange = closedBar.high - closedBar.low;
      double candleBody = MathAbs(closedBar.close - closedBar.open);
      bool decisiveBreak = candleRange > 0.0 && candleBody >= candleRange * 0.35;
      if(!decisiveBreak)
         continue;

      if(prevHighShift > 0 && closedBar.close > rates[prevHighShift].high + breakBuffer)
      {
         bool isChoch = scanTrend == TREND_BEAR;
         if((isChoch && UseCHOCH) || (!isChoch && UseBOS) || (UseBOS && UseCHOCH))
            RecordBullishStructure(isChoch, rates[prevHighShift].high, rates[prevHighShift].time, closedBar.time);
         scanTrend = TREND_BULL;
         if(latestBullBreakTime == 0)
            latestBullBreakTime = closedBar.time;
      }

      if(prevLowShift > 0 && closedBar.close < rates[prevLowShift].low - breakBuffer)
      {
         bool isChoch = scanTrend == TREND_BULL;
         if((isChoch && UseCHOCH) || (!isChoch && UseBOS) || (UseBOS && UseCHOCH))
            RecordBearishStructure(isChoch, rates[prevLowShift].low, rates[prevLowShift].time, closedBar.time);
         scanTrend = TREND_BEAR;
         if(latestBearBreakTime == 0)
            latestBearBreakTime = closedBar.time;
      }
   }

   g_recentBullStructureTime = latestBullBreakTime > 0 ? latestBullBreakTime : g_recentBullStructureTime;
   g_recentBearStructureTime = latestBearBreakTime > 0 ? latestBearBreakTime : g_recentBearStructureTime;
   if(scanTrend != TREND_NONE)
      g_trendDirection = scanTrend;
}

void EvaluateLiquiditySweeps(MqlRates &rates[])
{
   if(!UseLiquidity || ArraySize(g_liquidity) == 0)
      return;

   double tolerance = EffectiveLiquidityTolerance(rates);
   int limit = MathMin(ArraySize(rates) - 1, 25);

   for(int barShift = limit; barShift >= 1; barShift--)
   {
      MqlRates closedBar = rates[barShift];
      for(int i = 0; i < ArraySize(g_liquidity); i++)
      {
         if(!g_liquidity[i].active)
            continue;

         if(g_liquidity[i].highs && closedBar.high > g_liquidity[i].price + tolerance && closedBar.close < g_liquidity[i].price)
         {
            g_recentBearSweepTime = closedBar.time;
            DrawTextLabel(StringFormat("%sSweep.Bear.%I64d", PREFIX_STRUCTURE, closedBar.time), closedBar.time, closedBar.high, "Liquidity Sweep", clrRed);
         }

         if(!g_liquidity[i].highs && closedBar.low < g_liquidity[i].price - tolerance && closedBar.close > g_liquidity[i].price)
         {
            g_recentBullSweepTime = closedBar.time;
            DrawTextLabel(StringFormat("%sSweep.Bull.%I64d", PREFIX_STRUCTURE, closedBar.time), closedBar.time, closedBar.low, "Liquidity Sweep", clrGreen);
         }
      }
   }
}

bool FindContextZone(bool bullish, double price, double &zoneMid, string &zoneKind)
{
   double bestDistance = DBL_MAX;
   bool found = false;
   double touchBuffer = LiquidityTolerancePoints * PointValue();

   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      if(!g_zones[i].active || g_zones[i].bullish != bullish)
         continue;

      if(price < g_zones[i].low - touchBuffer || price > g_zones[i].high + touchBuffer)
         continue;

      double mid = (g_zones[i].high + g_zones[i].low) * 0.5;
      double distance = MathAbs(price - mid);
      if(distance < bestDistance)
      {
         bestDistance = distance;
         zoneMid = mid;
         zoneKind = g_zones[i].kind;
         found = true;
      }
   }

   return found;
}

bool HasRecentBullishStructure()
{
   if(!UseBOS && !UseCHOCH)
      return true;
   int window = MathMax(SignalValidityBars, 8) * PeriodSeconds(ActiveTimeframe());
   return g_recentBullStructureTime > 0 && (TimeCurrent() - g_recentBullStructureTime) <= window;
}

bool HasRecentBearishStructure()
{
   if(!UseBOS && !UseCHOCH)
      return true;
   int window = MathMax(SignalValidityBars, 8) * PeriodSeconds(ActiveTimeframe());
   return g_recentBearStructureTime > 0 && (TimeCurrent() - g_recentBearStructureTime) <= window;
}

bool HasRecentBullishSweep()
{
   if(!UseLiquidity)
      return true;
   int window = SignalValidityBars * PeriodSeconds(ActiveTimeframe());
   return g_recentBullSweepTime > 0 && (TimeCurrent() - g_recentBullSweepTime) <= window;
}

bool HasRecentBearishSweep()
{
   if(!UseLiquidity)
      return true;
   int window = SignalValidityBars * PeriodSeconds(ActiveTimeframe());
   return g_recentBearSweepTime > 0 && (TimeCurrent() - g_recentBearSweepTime) <= window;
}

int CountOpenPositions()
{
   int count = 0;
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;
      count++;
   }
   return count;
}

int CountOpenPositionsByDirection(int direction)
{
   int count = 0;
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int posDirection = posType == POSITION_TYPE_BUY ? 1 : -1;
      if(posDirection == direction)
         count++;
   }
   return count;
}

int GetOpenBasketDirection()
{
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      return posType == POSITION_TYPE_BUY ? 1 : -1;
   }
   return 0;
}

bool GetLastBasketEntryPrice(int direction, double &entryPrice)
{
   bool found = false;
   datetime latestOpenTime = 0;
   double latestEntryPrice = 0.0;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int posDirection = posType == POSITION_TYPE_BUY ? 1 : -1;
      if(posDirection != direction)
         continue;

      datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
      if(!found || openTime >= latestOpenTime)
      {
         latestOpenTime = openTime;
         latestEntryPrice = PositionGetDouble(POSITION_PRICE_OPEN);
         found = true;
      }
   }

   if(found)
      entryPrice = latestEntryPrice;
   return found;
}

bool IsBetterScaleEntry(int direction, double candidateEntry)
{
   double lastEntryPrice = 0.0;
   if(!GetLastBasketEntryPrice(direction, lastEntryPrice))
      return true;

   double improvementBuffer = MathMax(PointValue(), (double)SymbolInfoInteger(_Symbol, SYMBOL_SPREAD) * PointValue() * 0.25);
   if(direction > 0)
      return candidateEntry < (lastEntryPrice - improvementBuffer);

   return candidateEntry > (lastEntryPrice + improvementBuffer);
}

bool HasDuplicateLevelTrade(int direction, double referenceLevel)
{
   if(CountOpenPositionsByDirection(direction) > 0)
      return false;

   double tolerance = DuplicateLevelBufferPoints * PointValue();
   if(g_lastTradeDirection == direction && MathAbs(g_lastTradeLevel - referenceLevel) <= tolerance && (TimeCurrent() - g_lastTradeTime) < TradeCooldownSeconds)
      return true;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(PositionGetSymbol(i) != _Symbol) continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber) continue;

      ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      int posDirection = posType == POSITION_TYPE_BUY ? 1 : -1;
      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      if(posDirection == direction && MathAbs(openPrice - referenceLevel) <= tolerance)
         return true;
   }

   return false;
}

double CalculateVolume(double stopPoints)
{
   if(LotSize > 0.0)
      return NormalizeVolume(LotSize);

   if(stopPoints <= 0.0 || RiskPercent <= 0.0)
      return 0.0;

   double riskAmount = AccountInfoDouble(ACCOUNT_BALANCE) * (RiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double point = PointValue();
   if(tickValue <= 0.0 || tickSize <= 0.0 || point <= 0.0)
      return 0.0;

   double stopDistancePrice = stopPoints * point;
   double moneyPerLot = (stopDistancePrice / tickSize) * tickValue;
   if(moneyPerLot <= 0.0)
      return 0.0;

   return NormalizeVolume(riskAmount / moneyPerLot);
}

bool MarginAvailable(ENUM_ORDER_TYPE type, double volume, double price)
{
   double margin = 0.0;
   if(!OrderCalcMargin(type, _Symbol, volume, price, margin))
      return false;
   return AccountInfoDouble(ACCOUNT_MARGIN_FREE) > margin * 1.1;
}

bool ResolveStructureStop(bool isBuy, double entry, double &sl, string &stopSource)
{
   MqlRates rates[];
   if(!LoadRates(rates))
      return false;

   double point = PointValue();
   double avgRangePoints = AverageRangePoints(rates, 1, MathMin(24, ArraySize(rates) - 1));
   double minimumDistance = ResolveMinimumStopDistancePrice();
   double structureBuffer = MathMax(minimumDistance * 1.2, MathMax(point * 12.0, avgRangePoints * 0.15 * point));

   bool foundSwing = false;
   bool foundZone = false;
   double swingAnchor = 0.0;
   double zoneAnchor = 0.0;

   SwingPoint swings[];
   int swingCount = CollectSwings(rates, !isBuy, swings, 12);
   for(int i = 0; i < swingCount; i++)
   {
      double candidate = swings[i].price;
      if(isBuy)
      {
         if(candidate >= entry)
            continue;
         if(!foundSwing || candidate > swingAnchor)
         {
            swingAnchor = candidate;
            foundSwing = true;
         }
      }
      else
      {
         if(candidate <= entry)
            continue;
         if(!foundSwing || candidate < swingAnchor)
         {
            swingAnchor = candidate;
            foundSwing = true;
         }
      }
   }

   for(int i = 0; i < ArraySize(g_zones); i++)
   {
      if(!g_zones[i].active || g_zones[i].bullish != isBuy)
         continue;

      double candidate = isBuy ? g_zones[i].low : g_zones[i].high;
      if(isBuy)
      {
         if(candidate >= entry)
            continue;
         if(!foundZone || candidate > zoneAnchor)
         {
            zoneAnchor = candidate;
            foundZone = true;
         }
      }
      else
      {
         if(candidate <= entry)
            continue;
         if(!foundZone || candidate < zoneAnchor)
         {
            zoneAnchor = candidate;
            foundZone = true;
         }
      }
   }

   double stopAnchor = 0.0;
   if(foundSwing && foundZone)
   {
      stopAnchor = isBuy ? MathMin(swingAnchor, zoneAnchor) : MathMax(swingAnchor, zoneAnchor);
      stopSource = "swing+zone";
   }
   else if(foundSwing)
   {
      stopAnchor = swingAnchor;
      stopSource = "swing";
   }
   else if(foundZone)
   {
      stopAnchor = zoneAnchor;
      stopSource = "zone";
   }
   else
   {
      return false;
   }

   sl = isBuy ? stopAnchor - structureBuffer : stopAnchor + structureBuffer;
   sl = NormalizePrice(sl);

   if(isBuy && sl >= entry)
      return false;
   if(!isBuy && sl <= entry)
      return false;

   return true;
}

double ResolveMinimumStopDistancePrice()
{
   double point = PointValue();
   if(point <= 0.0)
      return 0.0;

   int stopsLevelPoints = (int)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   int freezeLevelPoints = (int)SymbolInfoInteger(_Symbol, SYMBOL_TRADE_FREEZE_LEVEL);
   int requiredPoints = MathMax(stopsLevelPoints, freezeLevelPoints);

   if(requiredPoints <= 0)
      requiredPoints = 1;

   return requiredPoints * point;
}

void EnforceBrokerStopDistance(bool isBuy, double entry, double &sl, double &tp)
{
   double minimumDistance = ResolveMinimumStopDistancePrice();
   double extraBuffer = MathMax(PointValue() * 2.0, minimumDistance * 0.05);
   double requiredDistance = minimumDistance + extraBuffer;

   if(isBuy)
   {
      if((entry - sl) < requiredDistance)
         sl = entry - requiredDistance;
      if((tp - entry) < requiredDistance)
         tp = entry + requiredDistance;
   }
   else
   {
      if((sl - entry) < requiredDistance)
         sl = entry + requiredDistance;
      if((entry - tp) < requiredDistance)
         tp = entry - requiredDistance;
   }

   sl = NormalizePrice(sl);
   tp = NormalizePrice(tp);
}

bool PlaceTrade(bool isBuy, double referenceLevel, string reason)
{
   if(!EnableTrading || !g_licenseValid)
      return false;

   int direction = isBuy ? 1 : -1;
   int openPositions = CountOpenPositions();
   int basketDirection = GetOpenBasketDirection();

   if(openPositions >= MaxTrades)
      return false;
   if(openPositions == 0 && IsClosedTradeCooldownActive())
      return false;
   if(openPositions > 0 && basketDirection != 0 && basketDirection != direction)
      return false;
   if(TimeCurrent() - g_lastTradeTime < TradeCooldownSeconds)
      return false;
   if(!PassesSpreadFilter() || !IsTradingHourAllowed() || !PassesNewsFilterPlaceholder())
      return false;
   if(HasDuplicateLevelTrade(direction, referenceLevel))
      return false;

   double entry = isBuy ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(openPositions > 0 && !IsBetterScaleEntry(direction, entry))
      return false;

   double sl = 0.0;
   string stopSource = "fixed";
   if(!ResolveStructureStop(isBuy, entry, sl, stopSource))
   {
      double fallbackDistance = MathMax(SL_Points, 1.0) * PointValue();
      sl = isBuy ? entry - fallbackDistance : entry + fallbackDistance;
      stopSource = "fixed";
   }

   double minimumDistance = ResolveMinimumStopDistancePrice();
   double stopBuffer = MathMax(PointValue() * 2.0, minimumDistance * 0.05);
   double requiredDistance = minimumDistance + stopBuffer;
   if(isBuy && (entry - sl) < requiredDistance)
      sl = entry - requiredDistance;
   if(!isBuy && (sl - entry) < requiredDistance)
      sl = entry + requiredDistance;

   double actualRiskDistance = MathAbs(entry - sl);
   double rewardMultiple = UseRR ? MathMax(RiskReward, 2.0) : 2.0;
   double tp = isBuy ? entry + (actualRiskDistance * rewardMultiple) : entry - (actualRiskDistance * rewardMultiple);
   sl = NormalizePrice(sl);
   tp = NormalizePrice(tp);

   double stopPoints = MathAbs(entry - sl) / PointValue();
   double volume = CalculateVolume(stopPoints);
   if(volume <= 0.0)
      return false;

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(Slippage);

   ENUM_ORDER_TYPE orderType = isBuy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!MarginAvailable(orderType, volume, entry))
      return false;

   bool sent = isBuy
      ? trade.Buy(volume, _Symbol, 0.0, sl, tp, reason)
      : trade.Sell(volume, _Symbol, 0.0, sl, tp, reason);

   if(sent)
   {
      g_lastTradeLevel = referenceLevel;
      g_lastTradeDirection = isBuy ? 1 : -1;
      g_lastTradeTime = TimeCurrent();
      PrintFormat("[GoldX][SMC] %s opened at %.5f SL=%.5f TP=%.5f reason=%s stopSource=%s", isBuy ? "BUY" : "SELL", entry, sl, tp, reason, stopSource);
   }
   else
   {
      PrintFormat(
         "[GoldX][SMC] Trade send failed retcode=%d entry=%.5f sl=%.5f tp=%.5f minStop=%.5f",
         trade.ResultRetcode(),
         entry,
         sl,
         tp,
         ResolveMinimumStopDistancePrice()
      );
   }

   return sent;
}

void RebuildAnalysis(MqlRates &rates[])
{
   ArrayResize(g_zones, 0);
   ArrayResize(g_liquidity, 0);
   DeleteObjectsByPrefix(PREFIX_ROOT);

   DetectSupplyDemand(rates);
   DetectFVG(rates);
   DetectLiquidity(rates);
   EvaluateStructure(rates);
   EvaluateLiquiditySweeps(rates);
}

void TryExecuteEntry()
{
   if(!EnableTrading || !g_licenseValid)
      return;

   double price = (SymbolInfoDouble(_Symbol, SYMBOL_BID) + SymbolInfoDouble(_Symbol, SYMBOL_ASK)) * 0.5;
   double bullLevel = 0.0;
   double bearLevel = 0.0;
   string bullKind = "";
   string bearKind = "";
   bool bullishContext = (!UseSupplyDemand && !UseFVG) || FindContextZone(true, price, bullLevel, bullKind);
   bool bearishContext = (!UseSupplyDemand && !UseFVG) || FindContextZone(false, price, bearLevel, bearKind);

   bool bullishSweep = HasRecentBullishSweep();
   bool bearishSweep = HasRecentBearishSweep();
   bool bullishStructure = HasRecentBullishStructure();
   bool bearishStructure = HasRecentBearishStructure();
   bool bullishEma = PassesEmaSetupFilter(true);
   bool bearishEma = PassesEmaSetupFilter(false);

   bool bullishReversalSetup = bullishContext && bullishSweep && bullishStructure && bullishEma;
   bool bearishReversalSetup = bearishContext && bearishSweep && bearishStructure && bearishEma;
   bool bullishContinuationSetup = (bullishStructure || g_trendDirection == TREND_BULL) && bullishEma && g_trendDirection == TREND_BULL;
   bool bearishContinuationSetup = (bearishStructure || g_trendDirection == TREND_BEAR) && bearishEma && g_trendDirection == TREND_BEAR;

   bool canBuy = bullishReversalSetup || bullishContinuationSetup;
   bool canSell = bearishReversalSetup || bearishContinuationSetup;

   datetime currentBar = iTime(_Symbol, ActiveTimeframe(), 0);
   if(currentBar != 0 && currentBar != g_lastDecisionLogBar)
   {
      g_lastDecisionLogBar = currentBar;
      PrintFormat(
         "[GoldX][SMC] Entry check price=%.5f trend=%d bull(ctx=%d sweep=%d struct=%d ema=%d cont=%d) bear(ctx=%d sweep=%d struct=%d ema=%d cont=%d)",
         price,
         (int)g_trendDirection,
         bullishContext,
         bullishSweep,
         bullishStructure,
         bullishEma,
         bullishContinuationSetup,
         bearishContext,
         bearishSweep,
         bearishStructure,
         bearishEma,
         bearishContinuationSetup
      );
   }

   if(canBuy && !canSell)
   {
      bool continuationOnly = bullishContinuationSetup && !bullishReversalSetup;
      string buyReason = continuationOnly ? "SMC_BUY_EMA_CONTINUATION" : (bullKind == "" ? "SMC_BUY" : "SMC_BUY_" + bullKind);
      PlaceTrade(true, bullLevel > 0.0 ? bullLevel : price, buyReason);
   }

   if(canSell && !canBuy)
   {
      bool continuationOnly = bearishContinuationSetup && !bearishReversalSetup;
      string sellReason = continuationOnly ? "SMC_SELL_EMA_CONTINUATION" : (bearKind == "" ? "SMC_SELL" : "SMC_SELL_" + bearKind);
      PlaceTrade(false, bearLevel > 0.0 ? bearLevel : price, sellReason);
   }
}

int OnInit()
{
   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(Slippage);
   EventSetTimer(15);
   RefreshLastClosedTradeTime();

   if(!InitializeEmaHandles())
   {
      Print("[GoldX][SMC] EMA handle initialization failed.");
      return INIT_FAILED;
   }

   if(!VerifyLicense(true))
   {
      PrintFormat("[GoldX][SMC] License invalid: %s", g_lastLicenseError);
      ExpertRemove();
      return INIT_FAILED;
   }

   MqlRates rates[];
   if(LoadRates(rates))
      RebuildAnalysis(rates);
   else
      Print("[GoldX][SMC] Initial analysis skipped: unable to load rates.");

   PrintFormat("[GoldX][SMC] Initialized symbol=%s timeframe=%s trading=%s", _Symbol, EnumToString(ActiveTimeframe()), EnableTrading ? "true" : "false");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   ReleaseEmaHandles();
   DeleteObjectsByPrefix(PREFIX_ROOT);
   PrintFormat("[GoldX][SMC] Removed reason=%d", reason);
}

void OnTimer()
{
   if((TimeCurrent() - g_lastLicenseCheck) >= MathMax(60, LicenseCacheSeconds / 2))
   {
      if(!VerifyLicense(true))
      {
         PrintFormat("[GoldX][SMC] License re-verification failed: %s", g_lastLicenseError);
         ExpertRemove();
      }
   }
}

void OnTick()
{
   if(!g_licenseValid)
      return;

   ManageOpenPositions();

   if(IsNewAnalysisBar())
   {
      MqlRates rates[];
      if(LoadRates(rates))
         RebuildAnalysis(rates);
   }

   TryExecuteEntry();
}

void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
{
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD || trans.deal == 0)
      return;

   if(!HistoryDealSelect(trans.deal))
      return;
   if(HistoryDealGetString(trans.deal, DEAL_SYMBOL) != _Symbol)
      return;
   if((ulong)HistoryDealGetInteger(trans.deal, DEAL_MAGIC) != MagicNumber)
      return;

   long entryType = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(entryType != DEAL_ENTRY_OUT && entryType != DEAL_ENTRY_OUT_BY)
      return;

   if(CountOpenPositions() > 0)
      return;

   datetime closeTime = (datetime)HistoryDealGetInteger(trans.deal, DEAL_TIME);
   if(closeTime < g_lastClosedTradeTime)
      return;
   if(closeTime == g_lastClosedTradeTime && trans.deal <= g_lastProcessedCloseDeal)
      return;

   g_lastClosedTradeTime = closeTime;
   g_lastProcessedCloseDeal = trans.deal;
   PrintFormat("[GoldX][SMC] Close detected at %s. Re-entry cooldown active for %d hour(s).", TimeToString(closeTime, TIME_DATE|TIME_MINUTES), ClosedTradeCooldownHours);
}
